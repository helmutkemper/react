import * as React from "react";
import "./Confirm.css"

const props = {
    title: "React and TypeScript"
};

interface IState {
    confirmOpen: boolean;
    confirmMessage: string;
}

interface IProps {
    open: boolean;
    title: string;
    content: string;
    cancelCaption?: string;
    okCaption?: string;
    onOkClick: () => void;
    onCancelClick: () => void;
}

class Confirm extends React.Component<{}, IState> {

    public static defaultProps = {
        open: false,
        cancelCaption: "Cancel",
        okCaption: "Ok"
    };

    /*private handleOkClick = () => {
        this.props.onOkClick();
    };

    private handleCancelClick = () => {
        this.props.onCancelClick();
    };*/

    constructor(props:{}){
        super(props);
        this.state = {
            confirmMessage: "Please hit the confirm button",
            confirmOpen: true,
        };
    }

    public render() {
        return (
            <div className={this.props.open ? "confirm-wrapper confirm-visible" : "confirm-wrapper"}>
                <div className="confirm-container">
                    <div className="confirm-title-container">
                        <span>{ this.props.title ? this.props.title : "no title found" }</span>
                    </div>
                    <div className="confirm-content-container">
                        <span>{ this.props.content }</span>
                    </div>
                    <div className="confirm-buttons-container">
                        <button className="confirm-cancel" onClick={this.handleCancelClick}>{ this.props.cancelCaption }</button>
                        <button className="confirm-ok" onClick={this.handleOkClick}>{ this.props.okCaption }</button>
                    </div>
                </div>
            </div>
        );
    }

}

export default Confirm;
